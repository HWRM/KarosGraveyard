--By Apollyon470
GUID = 
    { 110, 91, 157, 190, 18, 23, 250, 78, 144, 20, 41, 246, 181, 128, 214, 12, }
GameRulesName = "Kadeshi Swarmer Control"
Description = "Fuel Pods manage themselves"
GameSetupOptions = 
    { 
    { 
        name = "resources", 
        locName = "$3240", 
        tooltip = "$3239", 
        default = 1, 
        visible = 1, 
        choices = 
            { "$3241", "0.5", "$3242", "1.0", "$3243", "2.0", }, }, 
    { 
        name = "unitcaps", 
        locName = "$3214", 
        tooltip = "$3234", 
        default = 1, 
        visible = 1, 
        choices = 
            { "$3215", "Small", "$3216", "Normal", "$3217", "Large", }, }, 
    { 
        name = "resstart", 
        locName = "$3205", 
        tooltip = "$3232", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3206", "1000", "$3207", "3000", "$3208", "10000", "$3209", "0", }, }, 
    { 
        name = "lockteams", 
        locName = "$3220", 
        tooltip = "$3235", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3221", "yes", "$3222", "no", }, }, 
    { 
        name = "startlocation", 
        locName = "$3225", 
        tooltip = "$3237", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3226", "random", "$3227", "fixed", }, }, 
    }
dofilepath("data:scripts/scar/restrict.lua")
dofilepath("data:leveldata/multiplayer/lib/SobArray.lua")
dofilepath("data:leveldata/multiplayer/lib/SobGroupFunctions.lua")
Events = {}
Events.endGame = 
    { 
        { 
            { "wID = Wait_Start(5)", "Wait_End(wID)", }, 
        }, 
    }
function OnInit()
    MPRestrict()
    SobArrayLibInit() --initialize the SobArray functions
    Rule_Add("MainRule")
    SobArray_Create("EscortArray") --create the array we're going to use
    EscortArrayType={} --make a table for extra data
    EscortArrayTimer={} --and another for timing data
    Rule_Add("EscortRule")
end

function EscortRule()
    print("EscortRule Active")
    Rule_AddInterval("UpdateEscortRule",5)
    Rule_AddInterval("ManageEscortRule",5)
    SobGroup_Create("Orphan0")
    SobGroup_Create("Orphan1")
    SobGroup_Create("Orphan2")
    SobGroup_Create("Orphan3")
    SobGroup_Create("Orphan4")
    SobGroup_Create("Orphan5")
    Rule_AddInterval("watchOrphans",180);
    Rule_AddInterval("checkDistance",5)
    Rule_Remove("EscortRule")
end

function MainRule()
    local playerIndex = 0
    local playerCount = Universe_PlayerCount()
    while  playerIndex<playerCount do
        if  Player_IsAlive(playerIndex)==1 then
            if  Player_HasShipWithBuildQueue(playerIndex)==0 then
                Player_Kill(playerIndex)
            end 

        end 

        playerIndex = (playerIndex + 1)
    end 
    
    local numAlive = 0
    local numEnemies = 0
    local gameOver = 1
    playerIndex = 0
    while  playerIndex<playerCount do
        if  Player_IsAlive(playerIndex)==1 then
            local otherPlayerIndex = 0
            while  otherPlayerIndex<playerCount do
                if  AreAllied(playerIndex, otherPlayerIndex)==0 then
                    if  Player_IsAlive(otherPlayerIndex)==1 then
                        gameOver = 0
                    else
                        numEnemies = (numEnemies + 1)
                    end 

                end 

                otherPlayerIndex = (otherPlayerIndex + 1)
            end 

            numAlive = (numAlive + 1)
        end 

        playerIndex = (playerIndex + 1)
    end 

    if  numEnemies==0 and numAlive>0 then
        gameOver = 0
    end 

    if  gameOver==1 then
        Rule_Add("waitForEnd")
        Event_Start("endGame")
        Rule_Remove("MainRule")
    end 

end

function UpdateEscortRule()
    --get a group of all ships to use as a reference
    Update_AllShips()
    
    --get the ships we need to have escorts for
    SobGroup_Create("ShipsToEscort")
    SobGroup_Clear("ShipsToEscort")
    SobGroup_Create("tempSob")
    SobGroup_FillShipsByType ("tempSob", "AllShips", "hgn_carrier")
    SobGroup_SobGroupAdd("ShipsToEscort","tempSob")
    SobGroup_FillShipsByType ("tempSob", "AllShips", "hgn_mothership")
    SobGroup_SobGroupAdd("ShipsToEscort","tempSob")
    
    SobArray_GetAll("EscortArray")
    SobGroup_Create("EscortsToBeAdded")
    SobGroup_Clear("EscortsToBeAdded")
    SobGroup_FillSubstract("EscortsToBeAdded","ShipsToEscort","EscortArrayAll")
    
    if (SobGroup_Empty("EscortsToBeAdded") ~= 1) then
        --we have new ships to add
        --split them up and add them
        local NumNew = SobGroup_SplitGroupReference("NewEscortShips","EscortsToBeAdded","AllShips", SobGroup_Count("EscortsToBeAdded"))
        local i=0
        while (i<NumNew) do
            if ( SobGroup_Count("NewEscortShips"..i) <= 1) then --if this fails, two or more ships must be docking (i.e. just built).  Wait till next round
                --rules for EscortArrayType table: 
                --1: swarmer escort
                --2: adv swarmer escort
                if (SobGroup_AreAnyOfTheseTypes ("NewEscortShips"..i, "hgn_carrier") ==1)then
                    --fuelpods get 12 swarmers (2 squads)
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                end
                if (SobGroup_AreAnyOfTheseTypes ("NewEscortShips"..i, "hgn_mothership") ==1)then
                    --Needleships get 42 swarmers and 6 adv swarmers
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=0
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=2
                    EscortArrayTimer[index]=0
                end
            end
            i = i+1
        end
    end
    --we've cycled through all the ships and added them to the list if need be.
    --now go through the list and add any escorts that need to be recreated.
    local i=1
    local tempSob2 = "temp"
    while (SobArrayStatus["EscortArray"..i] ~= 0)do --cycle through all the elements in the escort list
        SobGroup_Create("asdftempsob2")
        SobGroup_Clear("asdftempsob2")
        SobGroup_Create("asdftempsob3")
        SobGroup_Clear("asdftempsob3")        
        if ( ( EscortArrayType[i] == 1 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_interceptor") ~= 1 ) ) then
            if (EscortArrayTimer[i] == 0) then
                tempSob2 = SobGroup_CreateShip ("EscortArray"..i,"hgn_interceptor")
                SobGroup_SobGroupAdd("EscortArray"..i,tempSob2)
                EscortArrayTimer[i] = 60
            else
                EscortArrayTimer[i] = EscortArrayTimer[i] - 5;
            end
        end
        if ( ( EscortArrayType[i] == 2 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_attackbomber") ~= 1 ) ) then
            if (EscortArrayTimer[i] == 0) then
                tempSob2 = SobGroup_CreateShip ("EscortArray"..i,"hgn_attackbomber")
                SobGroup_SobGroupAdd("EscortArray"..i,tempSob2)
                EscortArrayTimer[i] = 90
            else
                EscortArrayTimer[i] = EscortArrayTimer[i] - 5;
            end
        end
        
        i=i+1
    end
end

function Update_AllShips()
    local playerIndex = 0
    local playerCount = Universe_PlayerCount()
    SobGroup_Create("AllShips")
    SobGroup_Clear("AllShips")
    while  playerIndex<playerCount do
        SobGroup_SobGroupAdd("AllShips","Player_Ships"..playerIndex)
        playerIndex = playerIndex + 1
    end
end

--this function cycles through all the ships in our ships list and tells them what to do
function ManageEscortRule()
    local i=1
    local tempsob2
    SobGroup_Create("TempSob3")
    SobGroup_Create("TempSob4")
    while (SobArrayStatus["EscortArray"..i] ~= 0)do --cycle through all the elements in the escort list
        SobGroup_Clear("TempSob3")
        SobGroup_Clear("TempSob4")
        if SobGroup_Empty("EscortArray"..i) == 1 then
            SobGroup_Clear("EscortArray"..i)
            SobArrayStatus["EscortArray"..i] = -1
        end
        if (SobArrayStatus["EscortArray"..i] ~= -1) then --if we aren't at an invalid index
            if ( ( EscortArrayType[i] == 1 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_interceptor") == 1 ) ) then
                tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"hgn_interceptor")
                SobGroup_FillCompare("TempSob3",tempsob2,"EscortArray"..i)
                SobGroup_FillSubstract ("TempSob4","EscortArray"..i, "TempSob3")
                if ( SobGroup_Empty("TempSob3") ~= 1) then
                    if( (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_carrier") == 1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_mothership") ==1))then
                        --the mothership is alive, assign the escorts appropriately
                        if  (SobGroup_HealthPercentage ("TempSob3") < .5) then
                            SobGroup_DockSobGroup ("TempSob3", "EscortArray"..i)
                        else
                            if (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_mothership") ~=1) then
                                SobGroup_GuardSobGroup ("TempSob4","TempSob3")
                            end
                            if ( SobGroup_GetTactics ("TempSob3") ~= AggressiveTactics)then
                                SobGroup_SetTactics ("TempSob3", AggressiveTactics)
                            end
                        end
                    else
                        --the flagship is dead, slow the escorts and reuse the index
                        SobGroup_SetMaxSpeedMultiplier ("EscortArray"..i, .5)
                        SobGroup_SobGroupAdd("Orphan".. SobGroup_OwnedBy ("EscortArray"..i),"EscortArray"..i)
                        SobArrayStatus["EscortArray"..i] = -1
                    end
                end
            end
            if ( ( EscortArrayType[i] == 2 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_attackbomber") == 1 ) ) then
                tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"hgn_attackbomber")
                SobGroup_FillCompare("TempSob3",tempsob2,"EscortArray"..i)
                SobGroup_FillSubstract ("TempSob4","EscortArray"..i, "TempSob3")
                if ( SobGroup_Empty("TempSob3") ~= 1) then
                    if( (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_carrier") == 1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_mothership") ==1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Battlecruiser")==1))then
                        if  (SobGroup_HealthPercentage ("TempSob3") < .5) then
                            SobGroup_DockSobGroup ("TempSob3", "EscortArray"..i)
                        else
                            if (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_mothership") ~=1) then
                                SobGroup_GuardSobGroup ("TempSob4","TempSob3")
                            end
                            if ( SobGroup_GetTactics ("TempSob3") ~= AggressiveTactics)then
                                SobGroup_SetTactics ("TempSob3", AggressiveTactics)
                            end
                        end
                    else
                        --the flagship is dead, slow the escorts and reuse the index
                        SobGroup_SetMaxSpeedMultiplier ("EscortArray"..i, .5)
                        SobGroup_SobGroupAdd("Orphan".. SobGroup_OwnedBy ("EscortArray"..i),"EscortArray"..i)
                        SobArrayStatus["EscortArray"..i] = -1
                    end
                end
            end
        end
        i=i+1
    end
end

function watchOrphans()
    local playerIndex=0
    local playerCount = Universe_PlayerCount()
    while (playerIndex < playerCount) do
        print("Player " ..playerIndex.. " Orphans: "..SobGroup_Count("Orphan".. playerIndex))
        if (SobGroup_Empty("Orphan".. playerIndex) ~= 1)then
            SobGroup_Create("CurrentOrphans")
            SobGroup_Clear("CurrentOrphans")
            SobGroup_SobGroupAdd("CurrentOrphans","Orphan".. playerIndex)
            
            
            local orphanNum = SobGroup_SplitGroupReference("NewOrphan","CurrentOrphans","AllShips", SobGroup_Count("Orphan".. playerIndex))
            print(orphanNum)
            if (orphanNum >= 2) then
                tempSob2 = SobGroup_CreateShip ("Player_Ships"..playerIndex,"hgn_carrier")
                local index = SobArray_Add("EscortArray",tempSob2)
                SobGroup_SobGroupAdd("EscortArray"..index,"NewOrphan0")
                if ( SobGroup_AreAnyOfTheseTypes ("NewOrphan0", "hgn_interceptor") == 1 ) then
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=60
                else 
                    if ( SobGroup_AreAnyOfTheseTypes ("NewOrphan0", "hgn_attackbomber") == 1 ) then
                        EscortArrayType[index]=2
                        EscortArrayTimer[index]=90
                    end
                end
                SobGroup_SobGroupAdd("EscortArray"..index,"NewOrphan1")
                if ( SobGroup_AreAnyOfTheseTypes ("NewOrphan1", "hgn_interceptor") == 1 ) then
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=60
                else 
                    if ( SobGroup_AreAnyOfTheseTypes ("NewOrphan1", "hgn_attackbomber") == 1 ) then
                        EscortArrayType[index]=2
                        EscortArrayTimer[index]=90
                    end
                end
                print(SobGroup_Count("EscortArray"..index))
                SobGroup_FillSubstract ("Orphan".. playerIndex,"CurrentOrphans", "EscortArray"..index)
                print(SobGroup_Count("Orphan".. playerIndex))
            end
        end
        playerIndex = playerIndex + 1
    end
end

function checkDistance()
    local i=1
    local tempsob2
    SobGroup_Create("TempSob5")
    SobGroup_Create("TempSob6")
    while (SobArrayStatus["EscortArray"..i] ~= 0)do --cycle through all the elements in the escort list
        SobGroup_Clear("TempSob5")
        SobGroup_Clear("TempSob6")
        --if SobGroup_Empty("EscortArray"..i) == 1 then
         --   SobGroup_Clear("EscortArray"..i)
        --    SobArrayStatus["EscortArray"..i] = -1
        --end
        if (SobArrayStatus["EscortArray"..i] ~= -1) then
            if ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_carrier") == 1 ) then
                tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"hgn_carrier")
                SobGroup_FillCompare("TempSob5",tempsob2,"EscortArray"..i)
                SobGroup_FillSubstract ("TempSob6","EscortArray"..i, "TempSob5")
                SobGroup_Clear(tempsob2)
                if (SobGroup_Empty("TempSob6") ~= 1)then
                    SobGroup_FillProximitySobGroup (tempsob2, "TempSob6", "TempSob5", 4000) 
                    if (SobGroup_Empty(tempsob2) == 1)then --tempsob2 != nill if the ships are close enough
                        SobGroup_SetMaxSpeedMultiplier ("TempSob6", .5)
                    else
                        SobGroup_SetMaxSpeedMultiplier ("TempSob6", 1)
                    end
                end
            end
            if ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "hgn_mothership") == 1 ) then
                tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"hgn_mothership")
                SobGroup_FillCompare("TempSob5",tempsob2,"EscortArray"..i)
                SobGroup_FillSubstract ("TempSob6","EscortArray"..i, "TempSob5")
                SobGroup_Clear(tempsob2)
                if (SobGroup_Empty("TempSob6") ~= 1)then
                    SobGroup_FillProximitySobGroup (tempsob2, "TempSob6", "TempSob5", 4000) 
                    if (SobGroup_Empty(tempsob2) == 1)then --tempsob2 != nill if the ships are close enough
                        SobGroup_SetMaxSpeedMultiplier ("TempSob6", .5)
                    else
                        SobGroup_SetMaxSpeedMultiplier ("TempSob6", 1)
                    end
                end
            end
        end
        i = i+1
    end
end

function waitForEnd()
    if  Event_IsDone("endGame") then
        setGameOver()
        Rule_Remove("waitForEnd")
    end 

end
