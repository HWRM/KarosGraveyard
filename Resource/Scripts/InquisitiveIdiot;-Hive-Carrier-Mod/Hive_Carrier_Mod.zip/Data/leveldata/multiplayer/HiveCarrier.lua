-- LuaDC version 0.9.19
-- 5/23/2004 11:21:45 PM
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
GUID = 
    { 110, 91, 157, 190, 18, 23, 250, 78, 144, 20, 41, 246, 181, 128, 214, 12, }
GameRulesName = "Hive Carrier Mod"
Description = "Identical to Deathmatch, only your carriers and mothership gain a number of escorts that are automatically replenished"
GameSetupOptions = 
    { 
    { 
        name = "resources", 
        locName = "$3240", 
        tooltip = "$3239", 
        default = 1, 
        visible = 1, 
        choices = 
            { "$3241", "0.5", "$3242", "1.0", "$3243", "2.0", }, }, 
    { 
        name = "unitcaps", 
        locName = "$3214", 
        tooltip = "$3234", 
        default = 1, 
        visible = 1, 
        choices = 
            { "$3215", "Small", "$3216", "Normal", "$3217", "Large", }, }, 
    { 
        name = "resstart", 
        locName = "$3205", 
        tooltip = "$3232", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3206", "1000", "$3207", "3000", "$3208", "10000", "$3209", "0", }, }, 
    { 
        name = "lockteams", 
        locName = "$3220", 
        tooltip = "$3235", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3221", "yes", "$3222", "no", }, }, 
    { 
        name = "startlocation", 
        locName = "$3225", 
        tooltip = "$3237", 
        default = 0, 
        visible = 1, 
        choices = 
            { "$3226", "random", "$3227", "fixed", }, }, 
    }
dofilepath("data:scripts/scar/restrict.lua")
dofilepath("data:leveldata/multiplayer/lib/SobArray.lua")
dofilepath("data:leveldata/multiplayer/lib/SobGroupFunctions.lua")
Events = {}
Events.endGame = 
    { 
        { 
            { "wID = Wait_Start(5)", "Wait_End(wID)", }, 
        }, 
    }
function OnInit()
    MPRestrict()
    SobArrayLibInit() --initialize the SobArray functions
    Rule_Add("MainRule")
    SobArray_Create("EscortArray") --create the array we're going to use
    EscortArrayType={} --make a table for extra data
    EscortArrayTimer={} --and another for timing data
    Rule_Add("EscortRule")
end

function EscortRule()
    print("EscortRule Active")
    Rule_AddInterval("UpdateEscortRule",5)
    Rule_AddInterval("ManageEscortRule",5)
    Rule_Remove("EscortRule")
end

function MainRule()
    local playerIndex = 0
    local playerCount = Universe_PlayerCount()
    while  playerIndex<playerCount do
        if  Player_IsAlive(playerIndex)==1 then
            if  Player_HasShipWithBuildQueue(playerIndex)==0 then
                Player_Kill(playerIndex)
            end 

        end 

        playerIndex = (playerIndex + 1)
    end 
    
    local numAlive = 0
    local numEnemies = 0
    local gameOver = 1
    playerIndex = 0
    while  playerIndex<playerCount do
        if  Player_IsAlive(playerIndex)==1 then
            local otherPlayerIndex = 0
            while  otherPlayerIndex<playerCount do
                if  AreAllied(playerIndex, otherPlayerIndex)==0 then
                    if  Player_IsAlive(otherPlayerIndex)==1 then
                        gameOver = 0
                    else
                        numEnemies = (numEnemies + 1)
                    end 

                end 

                otherPlayerIndex = (otherPlayerIndex + 1)
            end 

            numAlive = (numAlive + 1)
        end 

        playerIndex = (playerIndex + 1)
    end 

    if  numEnemies==0 and numAlive>0 then
        gameOver = 0
    end 

    if  gameOver==1 then
        Rule_Add("waitForEnd")
        Event_Start("endGame")
        Rule_Remove("MainRule")
    end 

end

function UpdateEscortRule()
    --get a group of all ships to use as a reference
    Update_AllShips()
    
    --get the ships we need to have escorts for
    SobGroup_Create("ShipsToEscort")
    SobGroup_Clear("ShipsToEscort")
    SobGroup_Create("tempSob")
    SobGroup_FillShipsByType ("tempSob", "AllShips", "Hgn_Carrier")
    SobGroup_SobGroupAdd("ShipsToEscort","tempSob")
    SobGroup_FillShipsByType ("tempSob", "AllShips", "Hgn_Mothership")
    SobGroup_SobGroupAdd("ShipsToEscort","tempSob")
    SobGroup_FillShipsByType ("tempSob", "AllShips", "Hgn_Battlecruiser")
    SobGroup_SobGroupAdd("ShipsToEscort","tempSob")
    
    SobArray_GetAll("EscortArray")
    SobGroup_Create("EscortsToBeAdded")
    SobGroup_Clear("EscortsToBeAdded")
    SobGroup_FillSubstract("EscortsToBeAdded","ShipsToEscort","EscortArrayAll")
    SobArray_List("EscortArray")
    
    if (SobGroup_Empty("EscortsToBeAdded") ~= 1) then
        --we have new ships to add
        --split them up and add them
        local NumNew = SobGroup_SplitGroupReference("NewEscortShips","EscortsToBeAdded","AllShips", SobGroup_Count("EscortsToBeAdded"))
        local i=0
        while (i<NumNew) do
            if ( SobGroup_Count("NewEscortShips"..i) <= 1) then --if this fails, two or more ships must be docking (i.e. just built).  Wait till next round
                --rules for EscortArrayType table: 
                --1: interceptor escort
                --2: bomber escort
                --1000: battlecruiser escort
                if (SobGroup_AreAnyOfTheseTypes ("NewEscortShips"..i, "Hgn_Carrier") ==1)then
                    --carriers get 3 interceptor escorts and 1 bomber escort
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=2
                    EscortArrayTimer[index]=60
                end
                if (SobGroup_AreAnyOfTheseTypes ("NewEscortShips"..i, "Hgn_Mothership") ==1)then
                    --The Mothership gets 5 interceptor escorts and 1 battlecruiser
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1000
                    EscortArrayTimer[index]=300
                end
                if (SobGroup_AreAnyOfTheseTypes ("NewEscortShips"..i, "Hgn_BattleCruiser") ==1)then
                    --battlecruisers get 2 interceptor escorts
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                    local index = SobArray_Add("EscortArray","NewEscortShips"..i)
                    EscortArrayType[index]=1
                    EscortArrayTimer[index]=45
                end
            end
            i = i+1
        end
    end
    --we've cycled through all the ships and added them to the list if need be.
    --now go through the list and add any escorts that need to be recreated.
    local i=1
    local tempSob2 = "temp"
    while (SobArrayStatus["EscortArray"..i] ~= 0)do --cycle through all the elements in the escort list
        SobGroup_Create("asdftempsob2")
        SobGroup_Clear("asdftempsob2")
        SobGroup_Create("asdftempsob3")
        SobGroup_Clear("asdftempsob3")        
        if ( ( EscortArrayType[i] == 1 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Interceptor") ~= 1 ) ) then
            if (EscortArrayTimer[i] == 0) then
                tempSob2 = SobGroup_CreateShip ("EscortArray"..i,"Hgn_Interceptor")
                SobGroup_SobGroupAdd("EscortArray"..i,tempSob2)
                EscortArrayTimer[i] = 45
            else
                EscortArrayTimer[i] = EscortArrayTimer[i] - 5;
            end
        end
        if ( ( EscortArrayType[i] == 2 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_AttackBomber") ~= 1 ) ) then
            if (EscortArrayTimer[i] == 0) then
                tempSob2 = SobGroup_CreateShip ("EscortArray"..i,"Hgn_AttackBomber")
                SobGroup_SobGroupAdd("EscortArray"..i,tempSob2)
                EscortArrayTimer[i] = 60
            else
                EscortArrayTimer[i] = EscortArrayTimer[i] - 5;
            end
        end
        if ( ( EscortArrayType[i] == 1000 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Battlecruiser") ~= 1 ) ) then           
            if (EscortArrayTimer[i] == 0) then
                tempSob2 = SobGroup_CreateShip ("EscortArray"..i,"Hgn_BattleCruiser")
                SobGroup_SobGroupAdd("EscortArray"..i,tempSob2)
                EscortArrayTimer[i] = 300
                --since this battlecruiser is already in the list (as an escort),
                --it would not normally have escorts added, so we work around by
                --adding escorts manually
                local index = SobArray_Add("EscortArray",tempSob2)
                EscortArrayType[index]=1
                EscortArrayTimer[index]=45
                local index = SobArray_Add("EscortArray",tempSob2)
                EscortArrayType[index]=1
                EscortArrayTimer[index]=45
            else
                EscortArrayTimer[i] = EscortArrayTimer[i] - 5;
            end
        end
        
        i=i+1
    end
end

function Update_AllShips()
    local playerIndex = 0
    local playerCount = Universe_PlayerCount()
    SobGroup_Create("AllShips")
    SobGroup_Clear("AllShips")
    while  playerIndex<playerCount do
        SobGroup_SobGroupAdd("AllShips","Player_Ships"..playerIndex)
        playerIndex = playerIndex + 1
    end
end

--this function cycles through all the ships in our ships list and tells them what to do
function ManageEscortRule()
    local i=1
    local tempsob2
    SobGroup_Create("TempSob3")
    while (SobArrayStatus["EscortArray"..i] ~= 0)do --cycle through all the elements in the escort list
        SobGroup_Clear("TempSob3")
        if SobGroup_Empty("EscortArray"..i) == 1 then
            SobGroup_Clear("EscortArray"..i)
            SobArrayStatus["EscortArray"..i] = -1
        end
        if ( ( EscortArrayType[i] == 1 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Interceptor") == 1 ) ) then
            tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"Hgn_Interceptor")
            SobGroup_FillCompare("TempSob3",tempsob2,"EscortArray"..i)
            if ( SobGroup_Empty("TempSob3") ~= 1) then
                if( (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Carrier") == 1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Mothership") ==1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Battlecruiser")==1))then
                    --the mothership is alive, assign the escorts appropriately
                    if  (SobGroup_HealthPercentage ("TempSob3") < .5) then
                        SobGroup_DockSobGroup ("TempSob3", "EscortArray"..i)
                    else
                        SobGroup_GuardSobGroup ("TempSob3", "EscortArray"..i)
                        if ( SobGroup_GetTactics ("TempSob3") ~= AggressiveTactics)then
                            SobGroup_SetTactics ("TempSob3", AggressiveTactics)
                        end
                    end
                else
                    --the mothership is dead, disable the escorts and reuse the index
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Attack, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Guard, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Move, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Dock, 0)
                end
            end
        end
        if ( ( EscortArrayType[i] == 2 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_AttackBomber") == 1 ) ) then
            tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"Hgn_AttackBomber")
            SobGroup_FillCompare("TempSob3",tempsob2,"EscortArray"..i)
            if ( SobGroup_Empty("TempSob3") ~= 1) then
                if( (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Carrier") == 1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Mothership") ==1) or (SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Battlecruiser")==1))then
                    if  (SobGroup_HealthPercentage ("TempSob3") < .5) then
                        SobGroup_DockSobGroup ("TempSob3", "EscortArray"..i)
                    else
                        SobGroup_GuardSobGroup ("TempSob3", "EscortArray"..i)
                        if ( SobGroup_GetTactics ("TempSob3") ~= AggressiveTactics)then
                            SobGroup_SetTactics ("TempSob3", AggressiveTactics)
                        end
                    end
                else
                    --the mothership is dead, disable the escorts and reuse the index
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Attack, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Guard, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Move, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Dock, 0)
                end
            end
        end
        if ( ( EscortArrayType[i] == 1000 ) and ( SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Battlecruiser") == 1 ) ) then
            tempsob2 = Player_GetShipsByType(SobGroup_OwnedBy ("EscortArray"..i),"Hgn_Battlecruiser")
            SobGroup_FillCompare("TempSob3",tempsob2,"EscortArray"..i)
            if ( SobGroup_Empty("TempSob3") ~= 1) then
                if(SobGroup_AreAnyOfTheseTypes ("EscortArray"..i, "Hgn_Mothership") ==1)then
                    SobGroup_GuardSobGroup ("TempSob3", "EscortArray"..i) 
                    if ( SobGroup_GetTactics ("TempSob3") ~= AggressiveTactics)then
                        SobGroup_SetTactics ("TempSob3", AggressiveTactics)
                    end                    
                else
                    --the mothership is dead, disable the escorts and reuse the index
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Attack, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Guard, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Move, 0)
                    SobGroup_AbilityActivate ("EscortArray"..i, AB_Dock, 0)
                end
            end
        end
        i=i+1
    end
end

function waitForEnd()
    if  Event_IsDone("endGame") then
        setGameOver()
        Rule_Remove("waitForEnd")
    end 

end
